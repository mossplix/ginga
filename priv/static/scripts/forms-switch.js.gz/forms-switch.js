var FormsSwitch = {

	create: function () {
		$('.bs-switch').bootstrapSwitch();
	},

	init: function () {
		this.create();
	}
}

